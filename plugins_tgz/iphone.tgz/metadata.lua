local metadata =
{
	plugin =
	{
		format = 'staticLibrary',
		staticLibs = { 'plugin_opus', },
		frameworks = {},
		frameworksOptional = {},
		-- usesSwift = true,
	},
}

return metadata
